import "./bootstrap";

// Import Alpine.js
//import Alpine from "alpinejs";

// Jadikan global agar bisa dipakai di Blade
//window.Alpine = Alpine;

// Jalankan Alpine
//Alpine.start();
