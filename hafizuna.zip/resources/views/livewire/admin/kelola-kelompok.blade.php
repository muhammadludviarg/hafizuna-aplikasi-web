<div>
    {{-- Header --}}
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Kelola Siswa dan Kelompok</h1>
        <p class="text-gray-600 mt-1">Kelola siswa dan kelompok setoran hafalan</p>
    </div>

    {{-- Flash Messages (Floating) --}}
    <div class="fixed top-4 right-4 z-[9999] w-96 space-y-4 pointer-events-none">
        @if (session()->has('success'))
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded shadow-lg flex justify-between items-start animate-fade-in-down transition-all duration-500 pointer-events-auto">
                <div class="flex items-center">
                    <svg class="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    <p>{{ session('success') }}</p>
                </div>
                <button onclick="this.parentElement.remove()" class="text-green-700 hover:text-green-900 font-bold ml-2">×</button>
            </div>
        @endif

        @if (session()->has('error'))
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded shadow-lg flex justify-between items-start animate-fade-in-down transition-all duration-500 pointer-events-auto">
                <div class="flex items-center">
                    <svg class="h-6 w-6 text-red-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                    <p>{{ session('error') }}</p>
                </div>
                <button onclick="this.parentElement.remove()" class="text-red-700 hover:text-red-900 font-bold ml-2">×</button>
            </div>
        @endif
    </div>

    {{-- Main Content --}}
    <div class="bg-white rounded-lg shadow-md border border-gray-200 p-6">
        {{-- Header --}}
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-lg font-semibold text-gray-800">Daftar Kelompok Hafalan</h2>
                <p class="text-sm text-gray-600 mt-1">Atur kelompok untuk efisiensi setoran hafalan</p>
            </div>
            <button wire:click="buatKelompok" 
                    class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                </svg>
                Buat Kelompok
            </button>
        </div>

        {{-- SEARCH BAR UNIVERSAL --}}
        <div class="mb-6">
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
                <input type="text" 
                    wire:model.live="search" 
                    placeholder="Cari nama kelompok, kelas, atau guru pembimbing..."
                    class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition">
            </div>
        </div>

        {{-- Table --}}
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Kelompok</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kelas</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Guru Pembimbing</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Jumlah Anggota</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($kelompok as $item)
                        <tr wire:key="kelompok-{{ $item->id_kelompok }}" class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">{{ $item->nama_kelompok }}</div>
                                <div class="text-xs text-gray-500">{{ $item->tahun_ajaran }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $item->kelas->nama_kelas ?? '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-sm font-semibold mr-2">
                                        {{ strtoupper(substr($item->guru->akun->nama_lengkap ?? 'G', 0, 1)) }}
                                    </div>
                                    <div class="text-sm text-gray-900">{{ $item->guru->akun->nama_lengkap ?? '-' }}</div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    {{ $item->siswa->count() }} siswa
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                                <button wire:click="editKelompok({{ $item->id_kelompok }})" 
                                        class="text-yellow-600 hover:text-yellow-900 p-2 rounded-lg hover:bg-yellow-50 transition">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                    </svg>
                                </button>
                                <button wire:click="hapusKelompok({{ $item->id_kelompok }})" 
                                        wire:confirm="Apakah Anda yakin ingin menghapus kelompok ini? Data target hafalan & progres siswa di kelompok ini juga akan terhapus."
                                        class="text-red-600 hover:text-red-900 p-2 rounded-lg hover:bg-red-50 transition">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                    </svg>
                                </button>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center justify-center text-gray-400">
                                    <svg class="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.084-1.284-.24-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.084-1.284.24-1.857m0 0a5.002 5.002 0 019.52 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                    </svg>
                                    <p class="text-lg font-medium">Belum ada kelompok</p>
                                    <p class="text-sm mt-1">Klik "Buat Kelompok" untuk menambah</p>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Modal Form --}}
    @if($isModalOpen)
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" wire:click="closeModal">
            <div class="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-lg bg-white" wire:click.stop>
                {{-- Modal Header --}}
                <div class="flex items-center justify-between pb-4 border-b">
                    <h3 class="text-xl font-semibold text-gray-900">
                        {{ $isEditMode ? 'Edit Kelompok' : 'Buat Kelompok Baru' }}
                    </h3>
                    <button wire:click="closeModal" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>

                {{-- Form --}}
                <form wire:submit.prevent="simpanKelompok" class="mt-4 space-y-4">
                    {{-- Nama Kelompok --}}
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Nama Kelompok</label>
                        <input type="text" wire:model="nama_kelompok" 
                               placeholder="Contoh: 5 Firdaus A"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 @error('nama_kelompok') border-red-400 @enderror">
                        @error('nama_kelompok') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Pilih Kelas --}}
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Pilih Kelas</label>
                        <select wire:model.live="id_kelas" 
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 @error('id_kelas') border-red-400 @enderror">
                            <option value="">Pilih kelas</option>
                            @foreach($daftar_kelas as $kelas)
                                <option value="{{ $kelas->id_kelas }}">{{ $kelas->nama_kelas }} - {{ $kelas->tahun_ajaran }}</option>
                            @endforeach
                        </select>
                        @error('id_kelas') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Guru Pembimbing --}}
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Guru Pembimbing</label>
                        <select wire:model="id_guru" 
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 @error('id_guru') border-red-400 @enderror">
                            <option value="">Pilih guru</option>
                            @foreach($daftar_guru as $guru)
                                <option value="{{ $guru->id_guru }}">{{ $guru->akun->nama_lengkap ?? 'Guru' }}</option>
                            @endforeach
                        </select>
                        @error('id_guru') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Periode Kelompok --}}
                    <div class="grid grid-cols-2 gap-4">
                        {{-- Tanggal Mulai --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Mulai</label>
                            <input type="date" wire:model="tgl_mulai" 
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 @error('tgl_mulai') border-red-400 @enderror">
                            @error('tgl_mulai') 
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        {{-- Tanggal Selesai --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Selesai</label>
                            <input type="date" wire:model="tgl_selesai" 
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 @error('tgl_selesai') border-red-400 @enderror">
                            @error('tgl_selesai') 
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    {{-- Pilih Siswa --}}
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Pilih Siswa</label>
                        
                        @if(count($daftar_siswa) > 0)
                            <div class="border rounded-lg max-h-60 overflow-y-auto p-3 space-y-2 @error('siswa_dipilih') border-red-400 @enderror">
                                @foreach($daftar_siswa as $siswa)
                                    @php
                                        // Cek apakah siswa sudah punya kelompok lain
                                        $kelompokLain = $siswa->kelompok->first();
                                        $sudahPunyaKelompok = $kelompokLain !== null;
                                    @endphp
                                    
                                    <label class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer 
                                                {{ $sudahPunyaKelompok ? 'bg-yellow-50 border border-yellow-200' : '' }}">
                                        <input type="checkbox" 
                                            wire:model="siswa_dipilih" 
                                            value="{{ $siswa->id_siswa }}" 
                                            class="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500">
                                        
                                        <span class="ml-3 flex-1">
                                            <span class="text-sm text-gray-700">{{ $siswa->nama_siswa }} ({{ $siswa->kode_siswa }})</span>
                                            
                                            {{-- Indikator siswa sudah ada di kelompok lain --}}
                                            @if($sudahPunyaKelompok)
                                                <span class="ml-2 text-xs text-yellow-700 bg-yellow-100 px-2 py-0.5 rounded-full">
                                                    Kelompok: {{ $kelompokLain->nama_kelompok }}
                                                </span>
                                            @endif
                                        </span>
                                    </label>
                                @endforeach
                            </div>
                            
                            <p class="mt-2 text-xs text-gray-500">
                                {{ count($siswa_dipilih) }} siswa dipilih
                            </p>
                            
                            {{-- Info untuk admin --}}
                            @if($daftar_siswa->where('kelompok', '!=', null)->count() > 0)
                                <div class="mt-2 bg-blue-50 border border-blue-200 p-2 rounded-lg">
                                    <p class="text-xs text-blue-800">
                                        <strong>Info:</strong>  Jika siswa yang ada di kelompok lain dipilih, siswa akan <strong>dipindahkan</strong> ke kelompok ini.
                                    </p>
                                </div>
                            @endif
                            
                        @else
                            <div class="border border-gray-300 rounded-lg p-4 text-center text-gray-500">
                                @if($id_kelas)
                                    <p class="text-sm">Tidak ada siswa di kelas ini</p>
                                @else
                                    <p class="text-sm">Pilih kelas terlebih dahulu</p>
                                @endif
                            </div>
                        @endif
                        
                        @error('siswa_dipilih') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Buttons --}}
                    <div class="flex justify-end gap-3 pt-4 border-t">
                        <button type="button" wire:click="closeModal" 
                                class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
                            Batal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                            Simpan Kelompok
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif
</div>